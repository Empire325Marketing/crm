<div class="card">
    <ul id="client-estimates-tabs" data-bs-toggle="ajax-tab" data-do-not-save-state="1" class="nav nav-tabs bg-white title" role="tablist">
        <li class="nav-item"><a role="presentation" data-bs-toggle="tab" href="javascript:;" data-bs-target="#client-estimates-tab"><?php echo app_lang("estimates"); ?></a></li>
        <?php if ($show_estimate_request_info) { ?>
            <li class="nav-item"><a role="presentation" data-bs-toggle="tab" href="<?php echo_uri("clients/estimate_requests/" . $client_info->id); ?>" data-bs-target="#client-estimate-requests"> <?php echo app_lang('estimate_requests'); ?></a></li>
        <?php } ?>
        <div class="tab-title clearfix no-border">
            <div class="title-button-group">
                <?php echo modal_anchor(get_uri("estimates/modal_form"), "<i data-feather='plus-circle' class='icon-16'></i> " . app_lang('add_estimate'), array("class" => "btn btn-default", "data-post-client_id" => $client_id, "title" => app_lang('add_estimate'))); ?>
            </div>
        </div>
    </ul>
    <div class="tab-content">
        <div role="tabpanel" class="tab-pane fade" id="client-estimates-tab">
            <div class="table-responsive">
                <table id="client-details-page-estimate-table" class="display" width="100%">
                </table>
            </div>
        </div>
        <div role="tabpanel" class="tab-pane fade" id="client-estimate-requests"></div>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function () {
        var currencySymbol = "<?php echo $client_info->currency_symbol; ?>";
        var showCommentOption = false;
        if ("<?php echo get_setting("enable_comments_on_estimates") == "1" ?>") {
            showCommentOption = true;
        }

        $("#client-details-page-estimate-table").appTable({
            source: '<?php echo_uri("estimates/estimate_list_data_of_client/" . $client_id) ?>',
            order: [[0, "desc"]],
            filterDropdown: [<?php echo $custom_field_filters; ?>],
            columns: [
                {visible: false, searchable: false},
                {visible: false, searchable: false},
                {title: "<?php echo app_lang("estimate") ?>", "class": "w20p all", "iDataSort": 1},
                {visible: false, searchable: false},
                {visible: false, searchable: false},
                {title: "<?php echo app_lang("estimate_date") ?>", "iDataSort": 4, "class": "w20p all"},
                {visible: false, searchable: false},
                {title: "<?php echo app_lang("amount") ?>", "class": "text-right w20p"},
                {title: "<?php echo app_lang("status") ?>", "class": "text-center w20p"},
                {visible: showCommentOption, title: "<?php echo app_lang("comments") ?>", "class": "text-center w50"}
<?php echo $custom_field_headers; ?>,
                {visible: false}
            ],
            summation: [{column: 7, dataType: 'currency', currencySymbol: currencySymbol}]
        });
    });
</script>